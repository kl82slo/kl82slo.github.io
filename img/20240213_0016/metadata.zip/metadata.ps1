# PowerShell script example
$registryKey = "HKLM:\SOFTWARE\WOW6432Node\MicroStrategy\Data sources\CastorServer"
$outputFile = "output.txt"

# Export the registry key to a text file
Get-Item -LiteralPath $registryKey | Get-ItemProperty | Out-File -FilePath $outputFile
